a = 'rishi'
print(a)
a = [a]
print(a)